'use client';

import { Activity, BookOpen, BellOff, Asterisk, Loader2 } from 'lucide-react';
import type { JSX } from 'react';
import { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from 'recharts';

// Типы для данных из вебхука
interface CampaignData {
  row_number?: number;
  Месяц?: string;
  Показы?: string | number;
  Клики?: string | number;
  "Kлики"?: string | number;
  clicks?: string | number;
  Clicks?: string | number;
  CTR?: number;
  "Расходы, USD"?: number;
  "Ср. цена за клик"?: number;
  "% показов на верх. поз."?: number;
  "% показов на сам. верх. поз."?: number;
  "Проц. получ. показ. в поиск. сети"?: number;
  "Коэфф. конверсии"?: number;
  "Стоимость/конв."?: number;
  Конверсии?: number;
  "Расход в BYN"?: number;
  "Цена конверсии в BYN"?: number;
}

export default function Home() {
  const [isLoading, setIsLoading] = useState(false);
  const [data, setData] = useState<CampaignData[]>([]);
  const [error, setError] = useState<string | null>(null);
  
  // Состояние для управления видимостью данных на графике
  const [visibleData, setVisibleData] = useState({
    Показы: true,
    Клики: true,
    Расходы: true,
    Конверсии: true
  });

  // Состояние для переключения между таблицей и графиком
  const [viewMode, setViewMode] = useState<'table' | 'chart'>('table');

  // Функция для переключения видимости данных
  const toggleDataVisibility = (dataType: keyof typeof visibleData) => {
    setVisibleData(prev => ({
      ...prev,
      [dataType]: !prev[dataType]
    }));
  };

  // Функция для нормализации данных (приведение к одному масштабу)
  const normalizeData = (value: number, max: number, min: number) => {
    if (max === min) return 50; // Если все значения одинаковые, возвращаем 50
    return ((value - min) / (max - min)) * 100;
  };

  // Функция для подготовки данных для графика
  const prepareChartData = () => {
    const rawData = data.map(item => {
      const clicks = item.Клики || item['Kлики'] || item.clicks || item.Clicks;
      return {
        Месяц: item.Месяц || 'N/A',
        Показы: typeof item.Показы === 'string' ? parseInt(item.Показы.replace(/\s/g, '')) : item.Показы || 0,
        Клики: typeof clicks === 'string' ? parseInt(clicks.toString().replace(/\s/g, '')) : clicks || 0,
        Расходы: item["Расходы, USD"] || 0,
        Конверсии: item.Конверсии || 0
      };
    });

    // Находим минимумы и максимумы для каждой серии
    const показыValues = rawData.map(d => d.Показы);
    const кликиValues = rawData.map(d => d.Клики);
    const расходыValues = rawData.map(d => d.Расходы);
    const конверсииValues = rawData.map(d => d.Конверсии);

    const показыMax = Math.max(...показыValues);
    const показыMin = Math.min(...показыValues);
    const кликиMax = Math.max(...кликиValues);
    const кликиMin = Math.min(...кликиValues);
    const расходыMax = Math.max(...расходыValues);
    const расходыMin = Math.min(...расходыValues);
    const конверсииMax = Math.max(...конверсииValues);
    const конверсииMin = Math.min(...конверсииValues);

    // Нормализуем данные
    return rawData.map(item => ({
      Месяц: item.Месяц,
      Показы: normalizeData(item.Показы, показыMax, показыMin),
      Клики: normalizeData(item.Клики, кликиMax, кликиMin),
      Расходы: normalizeData(item.Расходы, расходыMax, расходыMin),
      Конверсии: normalizeData(item.Конверсии, конверсииMax, конверсииMin),
      // Сохраняем оригинальные значения для тултипа
      Показы_original: item.Показы,
      Клики_original: item.Клики,
      Расходы_original: item.Расходы,
      Конверсии_original: item.Конверсии
    }));
  };

  const fetchData = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Попробуем сначала GET запрос, так как некоторые вебхуки поддерживают GET
      let response = await fetch('https://clecucuci.beget.app/webhook/0d670d64-ecd3-41fb-b267-f8dcd2196bc1', {
        method: 'GET',
        mode: 'cors',
        headers: {
          'Accept': 'application/json',
        },
      });
      
      // Если GET не работает, попробуем POST
      if (!response.ok) {
        response = await fetch('https://clecucuci.beget.app/webhook/0d670d64-ecd3-41fb-b267-f8dcd2196bc1', {
          method: 'POST',
          mode: 'cors',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
          },
        });
      }
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const result = await response.json();
      console.log('Received data:', result);
      setData(result);
    } catch (err) {
      console.error('Fetch error:', err);
      
      // Если запрос не удался, используем тестовые данные
      if (err instanceof Error && err.message.includes('fetch')) {
        setError('Не удалось загрузить данные с сервера. Показываем тестовые данные.');
        // Тестовые данные на основе реальных данных из вебхука
        const testData = [
          {
            row_number: 1,
            Месяц: "янв. 2024",
            Показы: "467 853",
            "Kлики": 8516,
            CTR: 0.0182,
            "Расходы, USD": 1170.32,
            "Ср. цена за клик": 0.14,
            "% показов на верх. поз.": 0.6095,
            "% показов на сам. верх. поз.": 0.3766,
            "Проц. получ. показ. в поиск. сети": 0.2507,
            "Коэфф. конверсии": 0.0397,
            "Стоимость/конв.": 3.46,
            Конверсии: 338.09,
            "Расход в BYN": 3780.13,
            "Цена конверсии в BYN": 10.38
          },
          {
            row_number: 2,
            Месяц: "фев 2024",
            Показы: "255 293",
            "Kлики": 5662,
            CTR: 0.0222,
            "Расходы, USD": 791.73,
            "Ср. цена за клик": 0.14,
            "% показов на верх. поз.": 0.6572,
            "% показов на сам. верх. поз.": 0.3867,
            "Проц. получ. показ. в поиск. сети": 0.382,
            "Коэфф. конверсии": 0.0603,
            "Стоимость/конв.": 2.32,
            Конверсии: 341.26,
            "Расход в BYN": 2557.29,
            "Цена конверсии в BYN": 6.96
          },
          {
            row_number: 3,
            Месяц: "мар. 2024",
            Показы: "323 973",
            "Kлики": 7943,
            CTR: 0.0245,
            "Расходы, USD": 1007.42,
            "Ср. цена за клик": 0.13,
            "% показов на верх. поз.": 0.6994,
            "% показов на сам. верх. поз.": 0.4097,
            "Проц. получ. показ. в поиск. сети": 0.3442,
            "Коэфф. конверсии": 0.0527,
            "Стоимость/конв.": 2.41,
            Конверсии: 418.25,
            "Расход в BYN": 3253.97,
            "Цена конверсии в BYN": 7.23
          }
        ];
        console.log('Using test data:', testData);
        setData(testData);
      } else {
        setError(err instanceof Error ? err.message : 'Произошла ошибка при загрузке данных');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-16">
        {/* Основной контент */}
        <main className="text-center mb-16">
          <h1 className="text-6xl font-bold text-gray-900 dark:text-white mb-4">
            Привет мир!
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
            Больше пока ничего
          </p>
          <button 
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 font-medium transition-colors mx-auto"
            onClick={fetchData}
            disabled={isLoading}
          >
            {isLoading ? <Loader2 className="animate-spin w-5 h-5" /> : <Activity className="w-5 h-5" />}
            {isLoading ? 'Загрузка...' : 'Загрузить график'}
          </button>
        </main>

        {/* Отображение данных */}
        {(data.length > 0 || error) && (
          <div className="mb-16">
            {error && (
              <div className="bg-yellow-100 dark:bg-yellow-900 border border-yellow-400 text-yellow-700 dark:text-yellow-300 px-4 py-3 rounded mb-4 max-w-4xl mx-auto">
                <strong>Внимание:</strong> {error}
              </div>
            )}
            
            {data.length > 0 && (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 max-w-6xl mx-auto">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 text-center">
                  Данные рекламной кампании
                </h2>
                
                {/* Переключатель режимов */}
                <div className="flex justify-center mb-6">
                  <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-1 flex">
                    <button
                      onClick={() => setViewMode('table')}
                      className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                        viewMode === 'table'
                          ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-white shadow-sm'
                          : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                      }`}
                    >
                      Таблица
                    </button>
                    <button
                      onClick={() => setViewMode('chart')}
                      className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                        viewMode === 'chart'
                          ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-white shadow-sm'
                          : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                      }`}
                    >
                      График
                    </button>
                  </div>
                </div>

                {/* Таблица */}
                {viewMode === 'table' && (
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                      <thead className="bg-gray-50 dark:bg-gray-700">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                            Месяц
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                            Показы
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                            Клики
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                            CTR
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                            Расходы USD
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                            Конверсии
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                        {data.map((item, index) => {
                          console.log(`Row ${index}:`, item);
                          return (
                          <tr key={index} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                              {item.Месяц || 'N/A'}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                              {item.Показы ? (typeof item.Показы === 'string' ? item.Показы : item.Показы.toLocaleString()) : 'N/A'}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                              {(() => {
                                // Проверяем разные возможные названия поля
                                const clicks = item.Клики || item['Kлики'] || item.clicks || item.Clicks;
                                console.log('Clicks field check:', { 
                                  'Клики': item.Клики, 
                                  'Kлики': item['Kлики'], 
                                  clicks: item.clicks, 
                                  Clicks: item.Clicks,
                                  allKeys: Object.keys(item)
                                });
                                return clicks !== undefined && clicks !== null 
                                  ? (typeof clicks === 'string' ? clicks : clicks.toLocaleString()) 
                                  : 'N/A';
                              })()}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                              {item.CTR ? (item.CTR * 100).toFixed(2) + '%' : 'N/A'}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                              {item["Расходы, USD"] ? '$' + item["Расходы, USD"].toFixed(2) : 'N/A'}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                              {item.Конверсии ? item.Конверсии.toFixed(0) : 'N/A'}
                            </td>
                          </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}

                {/* График */}
                {viewMode === 'chart' && (
                  <>
                    {/* Переключатели данных */}
                    <div className="flex flex-wrap justify-center gap-4 mb-4">
                      {Object.entries(visibleData).map(([key, isVisible]) => (
                        <label key={key} className="flex items-center space-x-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={isVisible}
                            onChange={() => toggleDataVisibility(key as keyof typeof visibleData)}
                            className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                          />
                          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                            {key}
                          </span>
                        </label>
                      ))}
                    </div>
                    
                    {/* Пояснение к графику */}
                    <div className="text-center mb-6">
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Данные нормализованы для лучшей видимости всех серий (0-100%)
                      </p>
                    </div>

                    {/* Area Chart */}
                    <div className="h-96">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={prepareChartData()}>
                          <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                          <XAxis 
                            dataKey="Месяц" 
                            className="text-xs"
                            tick={{ fontSize: 12 }}
                          />
                          <YAxis 
                            className="text-xs"
                            tick={{ fontSize: 12 }}
                            domain={[0, 100]}
                            tickFormatter={(value) => `${value}%`}
                          />
                          <Tooltip 
                            formatter={(value: any, name: string, props: any) => {
                              // Получаем оригинальное значение из данных
                              const originalValue = props.payload[`${name}_original`];
                              if (name === 'Расходы') return [`$${originalValue.toFixed(2)}`, name];
                              if (originalValue >= 1000000) return [`${(originalValue / 1000000).toFixed(1)}M`, name];
                              if (originalValue >= 1000) return [`${(originalValue / 1000).toFixed(1)}K`, name];
                              return [originalValue.toLocaleString(), name];
                            }}
                            labelStyle={{ color: '#374151' }}
                            contentStyle={{ 
                              backgroundColor: '#f9fafb', 
                              border: '1px solid #e5e7eb',
                              borderRadius: '8px'
                            }}
                          />
                          <Legend />
                          
                          {visibleData.Показы && (
                            <Area 
                              type="monotone" 
                              dataKey="Показы" 
                              stackId="1"
                              stroke="#3b82f6" 
                              fill="#3b82f6"
                              fillOpacity={0.6}
                              strokeWidth={2}
                              dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
                              activeDot={{ r: 6 }}
                            />
                          )}
                          
                          {visibleData.Клики && (
                            <Area 
                              type="monotone" 
                              dataKey="Клики" 
                              stackId="2"
                              stroke="#ef4444" 
                              fill="#ef4444"
                              fillOpacity={0.6}
                              strokeWidth={2}
                              dot={{ fill: '#ef4444', strokeWidth: 2, r: 4 }}
                              activeDot={{ r: 6 }}
                            />
                          )}
                          
                          {visibleData.Расходы && (
                            <Area 
                              type="monotone" 
                              dataKey="Расходы" 
                              stackId="3"
                              stroke="#10b981" 
                              fill="#10b981"
                              fillOpacity={0.6}
                              strokeWidth={2}
                              dot={{ fill: '#10b981', strokeWidth: 2, r: 4 }}
                              activeDot={{ r: 6 }}
                            />
                          )}
                          
                          {visibleData.Конверсии && (
                            <Area 
                              type="monotone" 
                              dataKey="Конверсии" 
                              stackId="4"
                              stroke="#f59e0b" 
                              fill="#f59e0b"
                              fillOpacity={0.6}
                              strokeWidth={2}
                              dot={{ fill: '#f59e0b', strokeWidth: 2, r: 4 }}
                              activeDot={{ r: 6 }}
                            />
                          )}
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </>
                )}
              </div>
            )}
          </div>
        )}
        
        {/* Блоки с описанием */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-center w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg mb-4 mx-auto">
              <BookOpen className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2 text-center">
              Документация
            </h3>
            <p className="text-gray-600 dark:text-gray-300 text-center">
              Изучите подробную документацию и руководства для быстрого старта с нашим продуктом.
            </p>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-center w-12 h-12 bg-green-100 dark:bg-green-900 rounded-lg mb-4 mx-auto">
              <BellOff className="w-6 h-6 text-green-600 dark:text-green-400" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2 text-center">
              Без уведомлений
            </h3>
            <p className="text-gray-600 dark:text-gray-300 text-center">
              Работайте без отвлекающих уведомлений. Сосредоточьтесь на важных задачах.
            </p>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-center w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-lg mb-4 mx-auto">
              <Asterisk className="w-6 h-6 text-purple-600 dark:text-purple-400" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2 text-center">
              Премиум функции
            </h3>
            <p className="text-gray-600 dark:text-gray-300 text-center">
              Получите доступ к расширенным возможностям и эксклюзивным функциям.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}